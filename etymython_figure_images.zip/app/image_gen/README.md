# Figure Image Generation Module

## Overview

This module generates Renaissance Studio Portrait style images for all 45 mythological figures using DALL-E 3, stores them in Google Cloud Storage, and serves them to the Cytoscape family tree visualization.

## Integration

### 1. Add to `app/main.py`

```python
# Add with other imports
from app.image_gen.routes import router as image_gen_router

# Add after creating FastAPI app
app.include_router(image_gen_router)
```

### 2. Update `requirements.txt`

Make sure these are included:
```
httpx>=0.24.0
Pillow>=10.0.0
openai>=1.0.0
google-cloud-storage>=2.0.0
google-cloud-secret-manager>=2.0.0
```

### 3. Replace `frontend/index.html`

The new `index.html` fetches images from `/api/v1/images/for-frontend` and displays them as Cytoscape node backgrounds.

## API Endpoints

### Figure Information
- `GET /api/v1/images/figures` - List all figure names
- `GET /api/v1/images/figures/{name}/prompt` - Get DALL-E prompt for a figure

### Image Generation
- `POST /api/v1/images/generate/{figure_name}` - Generate single image
- `POST /api/v1/images/generate-all` - Start batch generation (background)
- `GET /api/v1/images/generate-status` - Check batch progress

### Image Retrieval
- `GET /api/v1/images/generated` - List all generated images
- `GET /api/v1/images/generated/{name}` - Get URLs for specific figure
- `GET /api/v1/images/for-frontend` - Dict of figure_name → thumb_url for Cytoscape
- `GET /api/v1/images/stats` - Generation statistics

## Usage

### Generate All Images

```bash
# Start batch generation (runs in background)
curl -X POST "https://etymython-mnovne7bma-uc.a.run.app/api/v1/images/generate-all"

# Check progress
curl "https://etymython-mnovne7bma-uc.a.run.app/api/v1/images/generate-status"
```

### Generate Single Image

```bash
curl -X POST "https://etymython-mnovne7bma-uc.a.run.app/api/v1/images/generate/Zeus"
```

### PowerShell

```powershell
# Generate all
Invoke-RestMethod -Uri "https://etymython-mnovne7bma-uc.a.run.app/api/v1/images/generate-all" -Method POST

# Check status
Invoke-RestMethod -Uri "https://etymython-mnovne7bma-uc.a.run.app/api/v1/images/generate-status"

# Generate single
Invoke-RestMethod -Uri "https://etymython-mnovne7bma-uc.a.run.app/api/v1/images/generate/Zeus" -Method POST
```

## Cost Estimate

- 45 figures × $0.04 (standard) = **$1.80**
- 45 figures × $0.08 (HD) = **$3.60**

## File Structure

```
app/image_gen/
├── __init__.py
├── figure_prompts.py    # 45 figure descriptions + prompt generator
├── generator.py         # DALL-E 3 + GCS storage
└── routes.py            # FastAPI endpoints

frontend/
└── index.html           # Updated Cytoscape with image nodes

gs://etymython-media/
└── figures/
    ├── full/            # 1024×1024 images (for detail panel)
    │   ├── zeus.png
    │   ├── hera.png
    │   └── ...
    └── thumbs/          # 80×80 thumbnails (for graph nodes)
        ├── zeus_thumb.png
        ├── hera_thumb.png
        └── ...
```

## Style Template

All figures use the "Photorealistic Renaissance Studio Portrait" style:

```
Studio portrait photography styled like a Renaissance allegory: {name}, 
{description}, in neutral backdrop, dramatic Rembrandt lighting, centered 
bust composition filling 70% of frame. Symbolism: {symbols}. Ultra sharp, 
museum-quality, high contrast for thumbnail visibility, no text, no letters, 
no inscriptions.
```

Each figure has custom `description` and `symbols` tuned to their mythology.
