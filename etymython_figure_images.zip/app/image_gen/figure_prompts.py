"""
Etymython - Figure Image Generator
Generates Renaissance Studio Portrait style images for all mythological figures.
"""

# The winning style template
STYLE_TEMPLATE = """Studio portrait photography styled like a Renaissance allegory: {name}, {description}, in neutral backdrop, dramatic Rembrandt lighting, centered bust composition filling 70% of frame. Symbolism: {symbols}. Ultra sharp, museum-quality, high contrast for thumbnail visibility, no text, no letters, no inscriptions."""

# Figure-specific details for prompt generation
FIGURE_DETAILS = {
    # ============================================================
    # PRIMORDIALS
    # ============================================================
    "Chaos": {
        "description": "the primordial void from which all existence emerged, depicted as an ethereal androgynous figure dissolving into swirling darkness and light",
        "symbols": "swirling void particles, emerging sparks of creation, the boundary between existence and nothingness"
    },
    "Gaia": {
        "description": "the primordial Earth goddess and mother of all life, depicted as a majestic woman with skin like rich soil and hair flowing with vegetation",
        "symbols": "flowering vines in her hair, precious stones emerging from her form, roots and fertile earth"
    },
    "Uranus": {
        "description": "the primordial sky god and father of the Titans, depicted as a regal figure with star-filled deep blue skin and cosmic crown",
        "symbols": "constellation patterns on skin, celestial crown of stars, cosmic nebulae as robes"
    },
    "Tartarus": {
        "description": "the primordial pit and dungeon of the damned, depicted as a dark imposing figure emerging from infinite depth",
        "symbols": "chains disappearing into darkness, bronze gates behind, eternal shadows"
    },
    "Erebus": {
        "description": "the primordial personification of deep darkness, depicted as a figure of absolute shadow with barely visible noble features",
        "symbols": "consuming darkness, faint starlight defining edges, the boundary of shadow and void"
    },
    "Nyx": {
        "description": "the primordial goddess of night, depicted as a hauntingly beautiful woman cloaked in star-studded darkness",
        "symbols": "cloak of night sky with stars, crescent moon diadem, owl feathers, poppies for sleep"
    },
    "Chronos": {
        "description": "the primordial personification of eternal Time itself, depicted as an ageless figure both ancient and timeless",
        "symbols": "hourglass, antique astrolabe, ouroboros halo, subtle decay (wilted leaves) and renewal (sprout)"
    },
    "Hypnos": {
        "description": "the primordial god of sleep, depicted as a gentle youthful figure with drowsy half-lidded eyes",
        "symbols": "poppy flowers, soft feathered wings at temples, river Lethe mist, horn of sleep-inducing opium"
    },
    "Thanatos": {
        "description": "the primordial personification of peaceful death, depicted as a solemn but not fearsome figure with dark wings",
        "symbols": "inverted torch (life extinguished), black wings folded, butterfly (soul), gentle expression"
    },
    
    # ============================================================
    # TITANS
    # ============================================================
    "Cronus": {
        "description": "the Titan king who ruled during the Golden Age, depicted as a powerful bearded figure with cunning aged eyes",
        "symbols": "sickle (adamantine harpe), crown of the Golden Age, swaddled stone (Zeus substitute)"
    },
    "Rhea": {
        "description": "the Titan queen and mother of the Olympians, depicted as a nurturing maternal figure with sorrowful knowing eyes",
        "symbols": "lions flanking, tambourine/tympanum, swaddled infant shape, crown of towers (Cybele aspect)"
    },
    "Oceanus": {
        "description": "the Titan of the great world-ocean river, depicted as a powerful figure with crab-claw horns and fish-scale beard",
        "symbols": "endless river flowing from urn, serpentine fish tail suggested, world-encircling waters"
    },
    "Hyperion": {
        "description": "the Titan of heavenly light and father of the sun, depicted as a radiant lordly figure emanating golden luminosity",
        "symbols": "solar rays as crown, dawn colors reflecting on skin, pillar of light behind"
    },
    "Theia": {
        "description": "the Titan goddess of sight and shining light, depicted as a luminous woman with gleaming metallic skin undertones",
        "symbols": "golden and silver light, precious gems glinting, eyes that reflect all light, lunar and solar discs"
    },
    "Coeus": {
        "description": "the Titan of rational intelligence and the axis of heaven, depicted as a contemplative scholarly figure",
        "symbols": "celestial pole/axis, questioning gaze, constellation of Draco, scrolls of cosmic knowledge"
    },
    "Phoebe": {
        "description": "the Titan of prophetic radiance and the moon, depicted as an ethereal woman with silver luminescence",
        "symbols": "crescent moon crown, prophetic laurel, soft silver glow, Delphi oracle connection"
    },
    "Tethys": {
        "description": "the Titan goddess of fresh water and nursing, depicted as a gentle maternal oceanic figure",
        "symbols": "river streams flowing from hands, water lilies, nurturing expression, springs and fountains"
    },
    "Themis": {
        "description": "the Titan goddess of divine law and order, depicted as a blindfolded noble woman of perfect composure",
        "symbols": "scales of justice, sword, blindfold, book of divine law"
    },
    "Iapetus": {
        "description": "the Titan of mortality and craft, depicted as a weathered powerful figure, father of Prometheus",
        "symbols": "mortal lifespan imagery, western pillar of sky, craftsman tools, ancestral gravity"
    },
    "Mnemosyne": {
        "description": "the Titan goddess of memory and mother of the Muses, depicted as a serene contemplative woman",
        "symbols": "pool of reflection (memory), nine stars (her Muse daughters), ancient scrolls, distant gaze"
    },
    "Atlas": {
        "description": "the Titan condemned to hold up the sky, depicted as an immensely muscular straining figure",
        "symbols": "celestial sphere on shoulders, straining muscles, starry burden, western mountains"
    },
    "Helios": {
        "description": "the Titan god who drives the sun chariot, depicted as a radiant golden figure with blazing crown",
        "symbols": "radiate crown of sun rays, chariot reins suggested, all-seeing eyes, golden skin"
    },
    "Selene": {
        "description": "the Titan goddess of the moon, depicted as a pale luminous beauty with silver crescent in her hair",
        "symbols": "crescent moon diadem, billowing white robes like moonlight, torch of night, gentle silver glow"
    },
    
    # ============================================================
    # OLYMPIANS
    # ============================================================
    "Zeus": {
        "description": "the king of the Olympian gods and ruler of sky and thunder, depicted as a powerful regal figure with commanding presence",
        "symbols": "lightning bolt, eagle, oak wreath crown, royal scepter, storm clouds"
    },
    "Hera": {
        "description": "the queen of the gods and goddess of marriage, depicted as a majestic regal woman with proud bearing",
        "symbols": "peacock feathers, royal diadem, pomegranate, lotus-tipped scepter, wedding veil"
    },
    "Poseidon": {
        "description": "the god of the seas and earthquakes, depicted as a powerful bearded figure with ocean-weathered features",
        "symbols": "trident, hippocampus (sea-horse), dolphins, crashing waves, coral crown"
    },
    "Demeter": {
        "description": "the goddess of harvest and agriculture, depicted as a nurturing maternal figure with wheat-gold hair",
        "symbols": "sheaf of wheat, cornucopia, poppy flowers, torch (searching for Persephone), sickle"
    },
    "Hestia": {
        "description": "the goddess of hearth and home, depicted as a modest serene veiled woman with warm gentle features",
        "symbols": "eternal flame, hearth fire, kettle, veil of modesty, domestic warmth"
    },
    "Hades": {
        "description": "the god of the underworld and the dead, depicted as a stern dark-robed figure with shadowed commanding features",
        "symbols": "helm of invisibility (shadow over face), bident, Cerberus suggested, cypress, keys to underworld"
    },
    "Athena": {
        "description": "the goddess of wisdom and strategic warfare, depicted as a noble fierce-eyed woman in armor",
        "symbols": "owl, aegis with Medusa head, olive branch, Corinthian helmet, spear and shield"
    },
    "Apollo": {
        "description": "the god of sun, music, poetry and prophecy, depicted as an ideally beautiful young man radiating light",
        "symbols": "golden lyre, laurel wreath, silver bow, python/serpent, tripod of Delphi"
    },
    "Artemis": {
        "description": "the goddess of the hunt and wilderness, depicted as an athletic fierce young woman with wild beauty",
        "symbols": "silver bow and arrows, crescent moon, hunting hounds, deer, cypress tree"
    },
    "Ares": {
        "description": "the god of war and bloodshed, depicted as a powerful aggressive warrior with battle-scarred features",
        "symbols": "bronze helmet and armor, bloody spear, shield, vultures, burning torch of war"
    },
    "Hephaestus": {
        "description": "the god of forge and craftsmanship, depicted as a powerful rough-featured smith with noble bearing despite lameness",
        "symbols": "blacksmith hammer, tongs, anvil, forge flames, mechanical automaton parts"
    },
    "Dionysus": {
        "description": "the god of wine and ecstasy, depicted as an androgynously beautiful youth with wild intoxicated eyes",
        "symbols": "thyrsus (ivy-wrapped staff), grape vines, wine cup (kantharos), leopard skin, ivy crown"
    },
    "Aphrodite": {
        "description": "the goddess of love and beauty, depicted as the most beautiful woman imaginable with captivating allure",
        "symbols": "scallop shell, mirror, doves, roses, golden apple, myrtle wreath"
    },
    "Eros": {
        "description": "the god of love and desire, depicted as a beautiful winged youth with mischievous knowing eyes",
        "symbols": "golden bow and arrows, wings, torch of passion, roses, blindfold (love is blind)"
    },
    "Hermes": {
        "description": "the messenger god and guide of souls, depicted as an athletic clever-faced young man in traveler's garb",
        "symbols": "winged sandals (talaria), winged cap (petasos), caduceus (twin-snake staff), traveler's cloak"
    },
    
    # ============================================================
    # OTHER DEITIES
    # ============================================================
    "Morpheus": {
        "description": "the god of dreams who appears in human form, depicted as an ethereal shifting figure between wake and sleep",
        "symbols": "wings of shifting iridescence, poppy flowers, dreamlike mist, sleeping figures reflected in eyes"
    },
    "Pan": {
        "description": "the rustic god of shepherds and wild places, depicted as a goat-legged man with wild laughing features",
        "symbols": "pan pipes (syrinx), goat horns and legs, pine wreath, shepherd's crook, wild woodland"
    },
    "Nike": {
        "description": "the goddess of victory, depicted as a powerful winged woman with triumphant bearing",
        "symbols": "great wings spread, victory wreath (laurel), palm branch, triumphant expression"
    },
    
    # ============================================================
    # MORTALS/HEROES/NYMPHS
    # ============================================================
    "Narcissus": {
        "description": "the beautiful youth cursed to fall in love with his own reflection, depicted as stunningly handsome with tragic vanity",
        "symbols": "reflection in water, narcissus flowers, mirror, self-absorbed gaze, transformation moment"
    },
    "Echo": {
        "description": "the nymph cursed to only repeat others' words, depicted as a fading beautiful figure becoming insubstantial",
        "symbols": "fading translucent form, mountain rocks, sound waves visualized, reaching hands, eternal longing"
    },
    "Psyche": {
        "description": "the mortal princess whose beauty rivaled Aphrodite, depicted as an extraordinarily beautiful woman with butterfly wings",
        "symbols": "butterfly wings (soul), oil lamp, box of Persephone's beauty, wedding veil, immortality achieved"
    },
}

def generate_prompt(figure_name: str) -> str:
    """Generate a complete DALL-E prompt for a figure."""
    if figure_name not in FIGURE_DETAILS:
        raise ValueError(f"Unknown figure: {figure_name}")
    
    details = FIGURE_DETAILS[figure_name]
    
    return STYLE_TEMPLATE.format(
        name=figure_name,
        description=details["description"],
        symbols=details["symbols"]
    )

def get_all_figure_names() -> list[str]:
    """Get all figure names."""
    return list(FIGURE_DETAILS.keys())

def get_figure_count() -> int:
    """Get total number of figures."""
    return len(FIGURE_DETAILS)

# Quick test
if __name__ == "__main__":
    print(f"Total figures: {get_figure_count()}")
    print("\nSample prompt for Zeus:")
    print(generate_prompt("Zeus"))
