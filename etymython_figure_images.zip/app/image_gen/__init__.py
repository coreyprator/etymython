"""
Etymython - Figure Image Generation Module
"""
from .figure_prompts import (
    FIGURE_DETAILS,
    STYLE_TEMPLATE,
    generate_prompt,
    get_all_figure_names,
    get_figure_count
)
from .generator import (
    generate_figure_image,
    generate_and_store_figure,
    generate_all_figures,
    list_figure_images,
    get_existing_figures,
    get_figure_image_urls
)
from .routes import router

__all__ = [
    "FIGURE_DETAILS",
    "STYLE_TEMPLATE",
    "generate_prompt",
    "get_all_figure_names",
    "get_figure_count",
    "generate_figure_image",
    "generate_and_store_figure",
    "generate_all_figures",
    "list_figure_images",
    "get_existing_figures",
    "get_figure_image_urls",
    "router"
]
