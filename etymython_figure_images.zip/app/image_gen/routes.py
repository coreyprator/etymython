"""
Etymython - Figure Image Generation API Routes
"""
from fastapi import APIRouter, HTTPException, BackgroundTasks
from typing import Optional
from pydantic import BaseModel
import asyncio

from .figure_prompts import FIGURE_DETAILS, generate_prompt, get_all_figure_names
from .generator import (
    generate_and_store_figure,
    list_figure_images,
    get_existing_figures,
    get_figure_image_urls
)

router = APIRouter(prefix="/api/v1/images", tags=["Figure Images"])

class GenerationResult(BaseModel):
    figure_name: str
    success: bool
    full_url: Optional[str] = None
    thumb_url: Optional[str] = None
    error: Optional[str] = None

class FigurePrompt(BaseModel):
    figure_name: str
    description: str
    symbols: str
    full_prompt: str

@router.get("/figures")
async def get_all_figures() -> list[str]:
    """Get list of all figures that can have images generated."""
    return get_all_figure_names()

@router.get("/figures/{figure_name}/prompt")
async def get_figure_prompt(figure_name: str) -> FigurePrompt:
    """Get the DALL-E prompt for a specific figure."""
    if figure_name not in FIGURE_DETAILS:
        raise HTTPException(status_code=404, detail=f"Figure not found: {figure_name}")
    
    details = FIGURE_DETAILS[figure_name]
    return FigurePrompt(
        figure_name=figure_name,
        description=details["description"],
        symbols=details["symbols"],
        full_prompt=generate_prompt(figure_name)
    )

@router.get("/generated")
async def get_generated_images() -> list[dict]:
    """Get all generated figure images from GCS."""
    return list_figure_images()

@router.get("/generated/{figure_name}")
async def get_figure_image(figure_name: str) -> dict:
    """Get image URLs for a specific figure."""
    urls = get_figure_image_urls(figure_name)
    if not urls:
        raise HTTPException(status_code=404, detail=f"No image found for: {figure_name}")
    return {
        "figure_name": figure_name,
        **urls
    }

@router.post("/generate/{figure_name}")
async def generate_single(figure_name: str, quality: str = "standard") -> GenerationResult:
    """Generate image for a single figure."""
    if figure_name not in FIGURE_DETAILS:
        raise HTTPException(status_code=404, detail=f"Figure not found: {figure_name}")
    
    if quality not in ["standard", "hd"]:
        raise HTTPException(status_code=400, detail="Quality must be 'standard' or 'hd'")
    
    result = await generate_and_store_figure(figure_name, quality)
    
    return GenerationResult(
        figure_name=figure_name,
        success=result.get("success", False),
        full_url=result.get("full_url"),
        thumb_url=result.get("thumb_url"),
        error=result.get("error")
    )

# Background task for batch generation
generation_status = {
    "running": False,
    "current": None,
    "completed": 0,
    "total": 0,
    "results": []
}

async def batch_generate_task(figure_names: list[str], quality: str):
    """Background task to generate multiple images."""
    global generation_status
    
    generation_status["running"] = True
    generation_status["total"] = len(figure_names)
    generation_status["completed"] = 0
    generation_status["results"] = []
    
    for name in figure_names:
        generation_status["current"] = name
        
        result = await generate_and_store_figure(name, quality)
        generation_status["results"].append(result)
        generation_status["completed"] += 1
        
        # Delay between requests
        await asyncio.sleep(2.0)
    
    generation_status["running"] = False
    generation_status["current"] = None

@router.post("/generate-all")
async def generate_all(
    background_tasks: BackgroundTasks,
    quality: str = "standard",
    skip_existing: bool = True
) -> dict:
    """Start background generation of all figure images."""
    global generation_status
    
    if generation_status["running"]:
        return {
            "status": "already_running",
            "current": generation_status["current"],
            "completed": generation_status["completed"],
            "total": generation_status["total"]
        }
    
    figure_names = get_all_figure_names()
    
    if skip_existing:
        existing = set(get_existing_figures())
        figure_names = [n for n in figure_names if n not in existing]
    
    if not figure_names:
        return {
            "status": "complete",
            "message": "All figures already have images"
        }
    
    cost = len(figure_names) * (0.04 if quality == "standard" else 0.08)
    
    background_tasks.add_task(batch_generate_task, figure_names, quality)
    
    return {
        "status": "started",
        "figures_to_generate": len(figure_names),
        "estimated_cost": f"${cost:.2f}",
        "quality": quality
    }

@router.get("/generate-status")
async def get_generation_status() -> dict:
    """Get status of background generation."""
    return {
        "running": generation_status["running"],
        "current": generation_status["current"],
        "completed": generation_status["completed"],
        "total": generation_status["total"],
        "recent_results": generation_status["results"][-5:] if generation_status["results"] else []
    }

@router.get("/stats")
async def get_stats() -> dict:
    """Get statistics about figure images."""
    all_figures = get_all_figure_names()
    existing = get_existing_figures()
    
    return {
        "total_figures": len(all_figures),
        "images_generated": len(existing),
        "images_pending": len(all_figures) - len(existing),
        "existing_figures": existing,
        "pending_figures": [f for f in all_figures if f not in existing],
        "estimated_cost_remaining": f"${(len(all_figures) - len(existing)) * 0.04:.2f}"
    }

@router.get("/for-frontend")
async def get_images_for_frontend() -> dict:
    """
    Get image URLs formatted for Cytoscape frontend.
    Returns a dict mapping english_name to thumb_url.
    """
    images = list_figure_images()
    return {
        img["figure_name"]: img["thumb_url"]
        for img in images
    }
