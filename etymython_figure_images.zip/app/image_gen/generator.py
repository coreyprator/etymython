"""
Etymython - Production Figure Image Generator
Generates and stores images for all mythological figures.
"""
import os
import asyncio
import httpx
from datetime import datetime
from typing import Optional
from google.cloud import storage
from openai import OpenAI
from PIL import Image
import io

from .figure_prompts import generate_prompt, get_all_figure_names, FIGURE_DETAILS

# GCS bucket configuration
BUCKET_NAME = "etymython-media"
FIGURES_FOLDER = "figures"

def get_openai_client():
    """Get OpenAI client with API key from environment or Secret Manager."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        try:
            from google.cloud import secretmanager
            client = secretmanager.SecretManagerServiceClient()
            name = "projects/etymython-project/secrets/openai-api-key/versions/latest"
            response = client.access_secret_version(request={"name": name})
            api_key = response.payload.data.decode("UTF-8")
        except Exception as e:
            raise ValueError(f"Could not get OpenAI API key: {e}")
    return OpenAI(api_key=api_key)

def get_gcs_client():
    """Get GCS client."""
    return storage.Client()

async def generate_figure_image(figure_name: str, quality: str = "standard") -> dict:
    """
    Generate image for a single figure using DALL-E 3.
    
    Args:
        figure_name: Name of the mythological figure
        quality: "standard" ($0.04) or "hd" ($0.08)
    
    Returns:
        dict with generation results
    """
    if figure_name not in FIGURE_DETAILS:
        return {"success": False, "error": f"Unknown figure: {figure_name}"}
    
    prompt = generate_prompt(figure_name)
    client = get_openai_client()
    
    try:
        response = client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            size="1024x1024",
            quality=quality,
            n=1,
        )
        
        return {
            "figure_name": figure_name,
            "success": True,
            "dalle_url": response.data[0].url,
            "revised_prompt": response.data[0].revised_prompt,
            "original_prompt": prompt,
            "error": None
        }
    except Exception as e:
        return {
            "figure_name": figure_name,
            "success": False,
            "dalle_url": None,
            "revised_prompt": None,
            "original_prompt": prompt,
            "error": str(e)
        }

async def download_and_store_image(dalle_url: str, figure_name: str) -> dict:
    """
    Download image from DALL-E and store in GCS with thumbnail.
    
    Returns:
        dict with GCS URLs for full image and thumbnail
    """
    gcs_client = get_gcs_client()
    bucket = gcs_client.bucket(BUCKET_NAME)
    
    # Sanitize figure name for filename
    safe_name = figure_name.lower().replace(" ", "_")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Download image from DALL-E
    async with httpx.AsyncClient(timeout=60.0) as http_client:
        response = await http_client.get(dalle_url)
        image_data = response.content
    
    # Upload full-size image (1024x1024)
    full_filename = f"{safe_name}.png"
    full_path = f"{FIGURES_FOLDER}/full/{full_filename}"
    full_blob = bucket.blob(full_path)
    full_blob.upload_from_string(image_data, content_type="image/png")
    full_blob.make_public()
    
    # Create and upload thumbnail (80x80)
    img = Image.open(io.BytesIO(image_data))
    
    # Center crop to square
    width, height = img.size
    min_dim = min(width, height)
    left = (width - min_dim) // 2
    top = (height - min_dim) // 2
    img_cropped = img.crop((left, top, left + min_dim, top + min_dim))
    
    # Resize to 80x80
    img_thumb = img_cropped.resize((80, 80), Image.Resampling.LANCZOS)
    
    # Save thumbnail
    thumb_buffer = io.BytesIO()
    img_thumb.save(thumb_buffer, format="PNG")
    thumb_data = thumb_buffer.getvalue()
    
    thumb_filename = f"{safe_name}_thumb.png"
    thumb_path = f"{FIGURES_FOLDER}/thumbs/{thumb_filename}"
    thumb_blob = bucket.blob(thumb_path)
    thumb_blob.upload_from_string(thumb_data, content_type="image/png")
    thumb_blob.make_public()
    
    return {
        "figure_name": figure_name,
        "full_url": full_blob.public_url,
        "thumb_url": thumb_blob.public_url,
        "full_path": full_path,
        "thumb_path": thumb_path
    }

async def generate_and_store_figure(figure_name: str, quality: str = "standard") -> dict:
    """
    Full pipeline: generate image, download, create thumbnail, store in GCS.
    """
    # Generate with DALL-E
    gen_result = await generate_figure_image(figure_name, quality)
    
    if not gen_result["success"]:
        return gen_result
    
    # Download and store in GCS
    try:
        storage_result = await download_and_store_image(
            gen_result["dalle_url"],
            figure_name
        )
        
        return {
            "figure_name": figure_name,
            "success": True,
            "full_url": storage_result["full_url"],
            "thumb_url": storage_result["thumb_url"],
            "revised_prompt": gen_result["revised_prompt"],
            "error": None
        }
    except Exception as e:
        return {
            "figure_name": figure_name,
            "success": False,
            "full_url": None,
            "thumb_url": None,
            "revised_prompt": gen_result["revised_prompt"],
            "error": f"Storage failed: {str(e)}"
        }

async def generate_all_figures(
    delay_seconds: float = 2.0,
    quality: str = "standard",
    skip_existing: bool = True
) -> list[dict]:
    """
    Generate images for all figures.
    
    Args:
        delay_seconds: Delay between API calls to avoid rate limits
        quality: "standard" or "hd"
        skip_existing: If True, skip figures that already have images in GCS
    """
    figure_names = get_all_figure_names()
    results = []
    
    # Check existing images if skip_existing is True
    existing = set()
    if skip_existing:
        existing = set(get_existing_figures())
    
    for i, name in enumerate(figure_names):
        if name in existing:
            print(f"Skipping {name} (already exists)")
            results.append({
                "figure_name": name,
                "success": True,
                "skipped": True,
                "error": None
            })
            continue
        
        print(f"Generating {i+1}/{len(figure_names)}: {name}")
        result = await generate_and_store_figure(name, quality)
        results.append(result)
        
        # Delay between requests
        if i < len(figure_names) - 1 and name not in existing:
            await asyncio.sleep(delay_seconds)
    
    return results

def get_existing_figures() -> list[str]:
    """List figures that already have images in GCS."""
    try:
        gcs_client = get_gcs_client()
        bucket = gcs_client.bucket(BUCKET_NAME)
        blobs = bucket.list_blobs(prefix=f"{FIGURES_FOLDER}/full/")
        
        existing = []
        for blob in blobs:
            # Extract figure name from path like "figures/full/zeus.png"
            filename = blob.name.split("/")[-1]
            if filename.endswith(".png"):
                # Convert back to proper name (zeus -> Zeus)
                name = filename.replace(".png", "").replace("_", " ").title()
                existing.append(name)
        
        return existing
    except Exception:
        return []

def list_figure_images() -> list[dict]:
    """List all generated figure images from GCS."""
    try:
        gcs_client = get_gcs_client()
        bucket = gcs_client.bucket(BUCKET_NAME)
        
        images = []
        blobs = bucket.list_blobs(prefix=f"{FIGURES_FOLDER}/full/")
        
        for blob in blobs:
            filename = blob.name.split("/")[-1]
            if not filename.endswith(".png"):
                continue
                
            safe_name = filename.replace(".png", "")
            figure_name = safe_name.replace("_", " ").title()
            
            thumb_path = f"{FIGURES_FOLDER}/thumbs/{safe_name}_thumb.png"
            
            images.append({
                "figure_name": figure_name,
                "full_url": blob.public_url,
                "thumb_url": f"https://storage.googleapis.com/{BUCKET_NAME}/{thumb_path}",
                "created_at": blob.time_created.isoformat() if blob.time_created else None
            })
        
        return images
    except Exception as e:
        print(f"Error listing images: {e}")
        return []

def get_figure_image_urls(figure_name: str) -> Optional[dict]:
    """Get image URLs for a specific figure."""
    safe_name = figure_name.lower().replace(" ", "_")
    
    full_url = f"https://storage.googleapis.com/{BUCKET_NAME}/{FIGURES_FOLDER}/full/{safe_name}.png"
    thumb_url = f"https://storage.googleapis.com/{BUCKET_NAME}/{FIGURES_FOLDER}/thumbs/{safe_name}_thumb.png"
    
    return {
        "full_url": full_url,
        "thumb_url": thumb_url
    }
